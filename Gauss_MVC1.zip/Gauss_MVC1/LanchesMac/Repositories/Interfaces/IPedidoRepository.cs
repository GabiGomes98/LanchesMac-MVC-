﻿namespace LanchesMac.Repositories.Interfaces;

public interface IPedidoRepository
{
    void CriarPedido(Models.Pedido pedido);
}
