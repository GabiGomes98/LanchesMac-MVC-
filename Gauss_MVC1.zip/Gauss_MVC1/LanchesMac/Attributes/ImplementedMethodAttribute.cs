﻿namespace LanchesMac.Attributes
{
    /// <summary>
    /// Classe vazia que herda o Attributes, assim posso utilziar lá no ILancheRepository
    /// </summary>
    public class ImplementedMethodAttribute : Attribute
    {
        public ImplementedMethodAttribute(string name)
        {

        }
    }
}
