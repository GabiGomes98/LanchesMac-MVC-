﻿namespace LanchesMac.Services;

public interface ICookieService
{
    Guid GetCookie();
}
